const { createBot } = require('whatsapp-cloud-api');
const express = require('express')
var cors = require('cors')
const app = express();

(async () => {
  try {
    // replace the values below from the values you copied above
    const from = '112023351516997';
    const token = 'EAAiJd5CQYOABAIGWlGDWD1P9CL2Ad92x3PIgW5BElHn0kSpAOXndoZAG2dXG5qaC7LmX1m7gVa2aC6o8jfty7UyNZAH0ZBeHoPD8k63FKaSqODMtPHikbzmZC7B0UdWkNN3HxDak2EyCuB8Tuf1qm0MWt5bh5S50NuRbKmipRqC5oeKcSCzz';
    const to = '918530008530'; // your phone number without the leading '+'
    const webhookVerifyToken = 'busadsdasfdfdsbhbdfsdfdsffdsfhj'; // use a random value, e.g. 'bju#hfre@iu!e87328eiekjnfw'

    const bot = createBot(from, token);

    const result = await bot.sendText(to, 'Hello world');
    
    const result2 = await bot.sendTemplate(to, 'sample_issue_resolution', 'en_US', [{
   "type": "body",
   "parameters": [{
                "type": "text",
                "text": "Gautam"
            }]
      }] );
      
    console.log(result);
    console.log(result2);

    await bot.startExpressServer({
      webhookVerifyToken,
      port: 2000
    });

    await bot.startExpressServer({ webhookVerifyToken });
    // Listen to ALL incoming messages
    bot.on('message', async (msg) => {
      console.log(msg);
       if (msg.type === 'button') {
              await bot.sendText(msg.from, 'Received your button!');
           await bot.sendText(msg.from, 'Bot Rock');
       } 
                     if (msg.type === 'list_reply') {
              await bot.sendText(msg.from, 'Received your list_reply!');
                          await bot.sendText(msg.from, 'Bot Rock');
                     } 
              
        if (msg.type === 'button_reply') {
            await bot.sendText(msg.from, 'Received your button_reply!');
             await bot.sendText(msg.from, 'Bot Rock');
        } 
      if (msg.type === 'text') {
        await bot.sendText(msg.from, 'Received your text message!');
         await bot.sendText(msg.from, 'Bot Rock');
      } else if (msg.type === 'image') {
        await bot.sendText(msg.from, 'Received your image!');
         await bot.sendText(msg.from, 'Bot Rock');
      }
    
    });
  } catch (err) {
    console.log(err);
  }
})();
