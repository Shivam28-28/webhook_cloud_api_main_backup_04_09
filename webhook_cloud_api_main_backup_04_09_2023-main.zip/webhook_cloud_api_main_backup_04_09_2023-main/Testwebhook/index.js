var express = require('express')
  , bodyParser = require('body-parser');

var app = express();

app.use(bodyParser.urlencoded({extended: false}));
app.use(bodyParser.json())

app.get("/", function (request, response) {
  response.send('Simple WhatsApp Webhook tester</br>There is no front-end, see server.js for implementation!');
});

app.get('/webhook', function(req, res) {
    
    
  if (
    req.query['VERIFY_TOKEN'] == 'mode' &&
    req.query['WHATSAPP_TOKEN'] == 'EAAiJd5CQYOABAIGWlGDWD1P9CL2Ad92x3PIgW5BElHn0kSpAOXndoZAG2dXG5qaC7LmX1m7gVa2aC6o8jfty7UyNZAH0ZBeHoPD8k63FKaSqODMtPHikbzmZC7B0UdWkNN3HxDak2EyCuB8Tuf1qm0MWt5bh5S50NuRbKmipRqC5oeKcSCzz'
    
  ) { 
    //res.send(req.query['hub.challenge']);
    res.sendStatus(200);
  } else {
    res.sendStatus(400);
  }
});

app.post("/webhook", function (request, response) {
  console.log('Incoming webhook: ' + JSON.stringify(request.body));
  response.sendStatus(200);
});

var listener = app.listen(9000 , function () {
  console.log('Your app is listening on port ' + listener.address().port);
});