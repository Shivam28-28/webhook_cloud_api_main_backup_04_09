'use strict';

const express = require('express');
const bodyParser = require('body-parser');
const app = express().use(bodyParser.json()); // creates http server
const token = 'aBh16aHe90ptlDFg7'; // type here your verification token
let data = "";
app.listen(9000, () => console.log('Webhook is listening'));


app.get('/', (req, res) => {
    // check if verification token is correct
    if (req.query.token !== token) {
        return res.sendStatus(401);
    }
    console.log("WEBHOOK_VERIFIED");
    // return challenge
    return res.end(req.query.challenge);
});

// Add support for GET requests to our webhook
app.get('/webhook/:number/:whatsapp', (req, res) => {
  

// Parse the query params
  let mode = req.query["hub.mode"];
  let token = req.query["hub.verify_token"];
  let challenge = req.query["hub.challenge"];
  
 
  // Check if a token and mode is in the query string of the request
  if (mode && token) {
    // Check the mode and token sent is correct
    if (mode === "subscribe" && token === "aBh16aHe90ptlDFg7") {
      // Respond with the challenge token from the request
      console.log("WEBHOOK_VERIFIED");
      res.status(200).send(challenge);
    } else {
      // Respond with '403 Forbidden' if verify tokens do not match
      res.sendStatus(403);
    }
  }
});
//End point



app.post('/webhook/:number/:whatsapp', (req, res) => {
    // check if verification token is correct
    
          console.log(req.params.number);
        console.log(req.params.whatsapp);
         data = req.body;
        var str_json = JSON.stringify(data);
        console.log(str_json);
        var XMLHttpRequest = require('xhr2');
        var request= new XMLHttpRequest();
        request.open("POST", "https://ele.digiforest.in/sms/v1/webhook_incoming/"+req.params.whatsapp+"/"+req.params.number+"", true);
        request.open("POST", "http://api.digiforest.in/sms/v1/webhook_incoming/"+req.params.whatsapp+"/"+req.params.number+"", true);
        request.setRequestHeader("Content-type", "application/json");
        request.send(str_json);
        return res.end();

    // print request body
   // console.log(req.body);
});

///////////////////////////////////////////////
// app.get('/karix/webhook', (req, res) => {
  

// // Parse the query params
//   let mode = req.query["hub.mode"];
//   let token = req.query["hub.verify_token"];
//   let challenge = req.query["hub.challenge"];
  
 
//   // Check if a token and mode is in the query string of the request
//   if (mode && token) {
//     // Check the mode and token sent is correct
//     if (mode === "subscribe" && token === "KarixXhBb916et11") {
//       // Respond with the challenge token from the request
//       console.log("WEBHOOK_VERIFIED");
//       res.status(200).send(challenge);
//     } else {
//       // Respond with '403 Forbidden' if verify tokens do not match
//       res.sendStatus(403);
//     }
//   }
// });
